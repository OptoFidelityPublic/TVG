#ifndef _MISC_STDINT_H_
#define _MISC_STDINT_H_

#include <stdint.h>

#ifndef _UINTPTR_T_DEFINED
typedef unsigned long uintptr_t;
#endif

#endif //_MISC_STDINT_H_